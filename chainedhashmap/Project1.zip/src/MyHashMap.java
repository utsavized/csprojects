/**
 * <i>To test HashMap</i>
 * @author Antonio Claros Molina, Scott Krieder, and Utsav Pandey 
 * @date 09/15/2010 
 * @version 1.0
 */

public class MyHashMap{
	public MyHashMap(){
		
	}
}